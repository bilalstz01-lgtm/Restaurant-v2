#!/usr/bin/env bash
set -e
if [ ! -d android ]; then
  flutter create --org com.monresto --project-name resto_caisse --platforms android /tmp/gen
  cp -r /tmp/gen/android ./android
fi
