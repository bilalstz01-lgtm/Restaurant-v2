import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'models.dart';
import 'printer.dart';
import 'state.dart';

final msgKey = GlobalKey<ScaffoldMessengerState>();
void toast(String s) => msgKey.currentState?.showSnackBar(SnackBar(content: Text(s)));
String fdt(DateTime d) => DateFormat('dd/MM HH:mm').format(d);
const _numKb = TextInputType.numberWithOptions(decimal: true);
double? num_(String? s) => s == null ? null : double.tryParse(s.replaceAll(',', '.'));

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await app.load();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Caisse Resto',
        scaffoldMessengerKey: msgKey,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFFD35400), useMaterial3: true),
        home: ListenableBuilder(listenable: app, builder: (_, __) => app.resto == null ? const SetupScreen() : const Shell()),
      );
}

// ------------------------------------------------------------ helpers
Widget itemImage(String? path) {
  const ph = ColoredBox(color: Color(0x14000000), child: Center(child: Icon(Icons.restaurant, size: 36)));
  if (path == null || path.isEmpty) return ph;
  if (path.startsWith('http')) return Image.network(path, fit: BoxFit.cover, errorBuilder: (_, __, ___) => ph);
  return Image.file(File(path), fit: BoxFit.cover, errorBuilder: (_, __, ___) => ph);
}

Widget field(TextEditingController c, String label, {TextInputType? kb, ValueChanged<String>? onChanged}) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(controller: c, keyboardType: kb, onChanged: onChanged, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
    );

Future<String?> ask(BuildContext c, String title, {String? label, String init = '', TextInputType? kb}) {
  final ctl = TextEditingController(text: init);
  return showDialog<String>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: TextField(controller: ctl, autofocus: true, keyboardType: kb, decoration: InputDecoration(labelText: label)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(d, ctl.text.trim()), child: const Text('OK')),
      ],
    ),
  );
}

Widget stat(String l, String v) => Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(l, style: const TextStyle(fontSize: 13)),
          Text(v, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ]),
      ),
    );

// ------------------------------------------------------------ configuration
class SetupScreen extends StatefulWidget {
  final bool editing;
  const SetupScreen({super.key, this.editing = false});
  @override
  State<SetupScreen> createState() => _SetupState();
}

class _SetupState extends State<SetupScreen> {
  late final n = TextEditingController(text: app.resto?.name);
  late final a = TextEditingController(text: app.resto?.address);
  late final t = TextEditingController(text: app.resto?.phone);
  late final c = TextEditingController(text: app.resto?.currency ?? '€');
  late final f = TextEditingController(text: app.resto?.footer ?? 'Merci de votre visite !');

  Future<void> _save() async {
    if (n.text.trim().isEmpty) return toast('Le nom du restaurant est obligatoire.');
    await app.saveResto(Restaurant(n.text.trim(), a.text.trim(), t.text.trim(), c.text.trim().isEmpty ? '€' : c.text.trim(), f.text.trim()));
    if (widget.editing && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.editing ? 'Établissement' : 'Bienvenue : configuration')),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: ListView(padding: const EdgeInsets.all(16), children: [
              if (!widget.editing) const Padding(padding: EdgeInsets.only(bottom: 16), child: Text("Ces informations apparaîtront en en-tête de tous les tickets.")),
              field(n, 'Nom du restaurant'),
              field(a, 'Adresse'),
              field(t, 'Téléphone', kb: TextInputType.phone),
              field(c, 'Devise (€, FCFA, \$…)'),
              field(f, 'Message en bas du ticket'),
              FilledButton(onPressed: _save, child: const Text('Enregistrer')),
            ]),
          ),
        ),
      );
}

// ------------------------------------------------------------ structure
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  static const pages = <Widget>[TablesPage(), OrdersPage(), CashPage(), ExpensesPage(), ReportsPage(), SettingsPage()];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Row(children: [
            NavigationRail(
              selectedIndex: i,
              onDestinationSelected: (v) => setState(() => i = v),
              labelType: NavigationRailLabelType.all,
              destinations: const [
                NavigationRailDestination(icon: Icon(Icons.grid_view), label: Text('Tables')),
                NavigationRailDestination(icon: Icon(Icons.receipt_long), label: Text('Commandes')),
                NavigationRailDestination(icon: Icon(Icons.point_of_sale), label: Text('Caisse')),
                NavigationRailDestination(icon: Icon(Icons.account_balance_wallet), label: Text('Dépenses')),
                NavigationRailDestination(icon: Icon(Icons.bar_chart), label: Text('Rapports')),
                NavigationRailDestination(icon: Icon(Icons.settings), label: Text('Réglages')),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(child: Column(children: [const TopBar(), Expanded(child: pages[i])])),
          ]),
        ),
      );
}

class TopBar extends StatelessWidget {
  const TopBar({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final open = app.cashOpened != null;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              Text(app.resto?.name ?? '', style: Theme.of(ctx).textTheme.titleLarge),
              const Spacer(),
              Chip(label: Text(open ? 'Caisse ouverte' : 'Caisse fermée'), backgroundColor: open ? Colors.green.shade100 : Colors.red.shade100),
            ]),
          );
        },
      );
}

// ------------------------------------------------------------ tables
class TablesPage extends StatefulWidget {
  const TablesPage({super.key});
  @override
  State<TablesPage> createState() => _TablesState();
}

class _TablesState extends State<TablesPage> {
  int s = 0;

  void _go(BuildContext ctx, String svc, String? table, Order? ex) =>
      Navigator.push(ctx, MaterialPageRoute(builder: (_) => OrderScreen(order: ex ?? app.newOrder(svc, table))));

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final svc = AppState.services[s];
          final open = app.orders.where((o) => o.status == 'open' && o.service == svc).toList();
          final cards = <Widget>[];
          if (s < 2) {
            final n = s == 0 ? app.nSalle : app.nTerrasse;
            for (var k = 1; k <= n; k++) {
              final name = '${s == 0 ? 'T' : 'TR'}$k';
              final ex = open.where((o) => o.table == name).firstOrNull;
              final occ = ex != null;
              cards.add(InkWell(
                onTap: () => _go(ctx, svc, name, ex),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: occ ? Colors.deepOrange : Colors.green, width: 2),
                    borderRadius: BorderRadius.circular(14),
                    color: occ ? Colors.orange.shade50 : null,
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const Spacer(),
                    Text(occ ? money(ex.total) : 'Libre', style: TextStyle(color: occ ? Colors.deepOrange : Colors.green)),
                  ]),
                ),
              ));
            }
          } else {
            cards.add(InkWell(
              onTap: () => _go(ctx, svc, null, null),
              child: Container(
                decoration: BoxDecoration(border: Border.all(color: Colors.deepOrange), borderRadius: BorderRadius.circular(14)),
                child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.add, size: 36, color: Colors.deepOrange), Text('Nouvelle commande')])),
              ),
            ));
            for (final o in open) {
              cards.add(InkWell(
                onTap: () => _go(ctx, svc, null, o),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(border: Border.all(color: Colors.deepOrange, width: 2), borderRadius: BorderRadius.circular(14), color: Colors.orange.shade50),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('#${o.no}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    Text(fdt(o.date)),
                    const Spacer(),
                    Text(money(o.total), style: const TextStyle(color: Colors.deepOrange)),
                  ]),
                ),
              ));
            }
          }
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 8, children: [
                for (var k = 0; k < AppState.services.length; k++)
                  ChoiceChip(label: Text(AppState.services[k]), selected: s == k, onSelected: (_) => setState(() => s = k)),
              ]),
              const SizedBox(height: 10),
              Text('Commandes ouvertes : ${open.length}   En cours : ${money(open.fold<double>(0, (a, o) => a + o.total))}'),
              const SizedBox(height: 10),
              Expanded(child: GridView.extent(maxCrossAxisExtent: 170, childAspectRatio: 1.1, mainAxisSpacing: 10, crossAxisSpacing: 10, children: cards)),
            ]),
          );
        },
      );
}

// ------------------------------------------------------------ prise de commande
class OrderScreen extends StatefulWidget {
  final Order order;
  const OrderScreen({super.key, required this.order});
  @override
  State<OrderScreen> createState() => _OrderState();
}

class _OrderState extends State<OrderScreen> {
  String? cat;
  Order get o => widget.order;

  Future<void> _kitchen() async {
    if (!o.lines.any((l) => l.qty > l.sent)) return toast('Rien de nouveau à envoyer.');
    final err = await printLines(kitchenLines(o));
    if (err == null) app.markSent(o);
    toast(err ?? 'Envoyé en cuisine.');
  }

  Future<void> _pay(BuildContext ctx) async {
    if (app.cashOpened == null) return toast("Ouvrez d'abord la caisse (onglet Caisse).");
    final m = await showDialog<String>(
      context: ctx,
      builder: (d) => SimpleDialog(
        title: Text('Paiement : ${money(o.total)}'),
        children: [for (final x in AppState.methods) SimpleDialogOption(onPressed: () => Navigator.pop(d, x), child: Text(x, style: const TextStyle(fontSize: 18)))],
      ),
    );
    if (m == null) return;
    app.pay(o, m);
    final err = await printLines(receiptLines(o), kick: m == 'Espèces');
    toast(err == null ? 'Commande encaissée.' : 'Encaissée, mais impression échouée : $err');
    if (ctx.mounted) Navigator.pop(ctx);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final cats = app.categories;
          cat ??= cats.isEmpty ? null : cats.first;
          final its = app.items.where((i) => cat == null || i.category == cat).toList();
          return Scaffold(
            appBar: AppBar(title: Text(o.label)),
            body: Row(children: [
              Expanded(
                child: Column(children: [
                  SizedBox(
                    height: 56,
                    child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(8), children: [
                      for (final c in cats)
                        Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(c), selected: cat == c, onSelected: (_) => setState(() => cat = c))),
                    ]),
                  ),
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.all(8),
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 150, childAspectRatio: .85, crossAxisSpacing: 8, mainAxisSpacing: 8),
                      itemCount: its.length,
                      itemBuilder: (_, k) {
                        final it = its[k];
                        return Card(
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            onTap: () => app.addItem(o, it),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                              Expanded(child: itemImage(it.image)),
                              Padding(
                                padding: const EdgeInsets.all(6),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                                  Text(money(it.price)),
                                ]),
                              ),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
                ]),
              ),
              const VerticalDivider(width: 1),
              SizedBox(
                width: 330,
                child: Column(children: [
                  Padding(padding: const EdgeInsets.all(12), child: Align(alignment: Alignment.centerLeft, child: Text('${o.label}  #${o.no == 0 ? '-' : o.no}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)))),
                  Expanded(
                    child: o.lines.isEmpty
                        ? const Center(child: Text("Touchez un produit pour l'ajouter."))
                        : ListView(children: [
                            for (final l in List<Line>.of(o.lines))
                              ListTile(
                                dense: true,
                                title: Text(l.name),
                                subtitle: Text('${money(l.price)}${l.sent >= l.qty ? '  ✓ envoyé' : ''}'),
                                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                  IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => app.dec(o, l)),
                                  Text('${l.qty}', style: const TextStyle(fontSize: 16)),
                                  IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => app.inc(o, l)),
                                ]),
                              ),
                          ]),
                  ),
                  const Divider(height: 1),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Total', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      Text(money(o.total), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(children: [
                      Expanded(child: OutlinedButton.icon(onPressed: o.lines.isEmpty ? null : _kitchen, icon: const Icon(Icons.send), label: const Text('Envoyer'))),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: o.lines.isEmpty ? null : () async { final e = await printLines(receiptLines(o, title: 'ADDITION')); toast(e ?? 'Addition imprimée.'); },
                          icon: const Icon(Icons.receipt),
                          label: const Text('Addition'),
                        ),
                      ),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: SizedBox(width: double.infinity, height: 48, child: FilledButton(onPressed: o.lines.isEmpty ? null : () => _pay(ctx), child: Text('Encaisser ${money(o.total)}'))),
                  ),
                ]),
              ),
            ]),
          );
        },
      );
}

// ------------------------------------------------------------ commandes
class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});
  @override
  State<OrdersPage> createState() => _OrdersState();
}

class _OrdersState extends State<OrdersPage> {
  int f = 0;
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final now = DateTime.now();
          final l = app.orders.where((o) => f == 0 ? o.status == 'open' : f == 1 ? sameDay(o.paidAt ?? o.date, now) : true).toList()
            ..sort((a, b) => b.date.compareTo(a.date));
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 8, children: [
                for (var k = 0; k < 3; k++) ChoiceChip(label: Text(['En cours', "Aujourd'hui", 'Historique'][k]), selected: f == k, onSelected: (_) => setState(() => f = k)),
              ]),
              Expanded(
                child: l.isEmpty
                    ? const Center(child: Text('Aucune commande.'))
                    : ListView(children: [
                        for (final o in l)
                          Card(
                            child: ListTile(
                              title: Text('#${o.no} · ${o.label}'),
                              subtitle: Text('${fdt(o.date)} · ${o.status == 'open' ? 'En cours' : 'Payée (${o.pay})'}'),
                              trailing: Text(money(o.total), style: const TextStyle(fontWeight: FontWeight.bold)),
                              onTap: () async {
                                if (o.status == 'open') {
                                  Navigator.push(ctx, MaterialPageRoute(builder: (_) => OrderScreen(order: o)));
                                } else {
                                  final ok = await showDialog<bool>(
                                    context: ctx,
                                    builder: (d) => AlertDialog(
                                      title: Text('Réimprimer le ticket #${o.no} ?'),
                                      actions: [
                                        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Non')),
                                        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Imprimer')),
                                      ],
                                    ),
                                  );
                                  if (ok == true) { final e = await printLines(receiptLines(o)); toast(e ?? 'Ticket imprimé.'); }
                                }
                              },
                            ),
                          ),
                      ]),
              ),
            ]),
          );
        },
      );
}

// ------------------------------------------------------------ caisse
class CashPage extends StatelessWidget {
  const CashPage({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final a = app.cashOpened;
          if (a == null) {
            return Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('Caisse fermée', style: TextStyle(fontSize: 22)),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () async {
                    final v = num_(await ask(ctx, 'Fond de caisse', label: 'Montant en espèces', kb: _numKb));
                    if (v != null) app.openCash(v);
                  },
                  child: const Text('Ouvrir la caisse'),
                ),
              ]),
            );
          }
          final paid = app.paidSince(a);
          final sales = paid.fold<double>(0, (s, o) => s + o.total);
          final by = app.byMethod(paid);
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text('Caisse ouverte depuis le ${fdt(a)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Wrap(spacing: 12, runSpacing: 12, children: [
              stat('Fond de caisse', money(app.cashFloat)),
              stat('Ventes', money(sales)),
              stat('Tickets', '${paid.length}'),
              stat('Espèces attendues', money(app.expectedCash)),
            ]),
            const SizedBox(height: 16),
            const Text('Encaissements par moyen de paiement', style: TextStyle(fontWeight: FontWeight.bold)),
            for (final e in by.entries) ListTile(dense: true, title: Text(e.key), trailing: Text(money(e.value))),
            const SizedBox(height: 12),
            Wrap(spacing: 12, runSpacing: 8, children: [
              OutlinedButton.icon(onPressed: () async => toast(await openDrawer() ?? 'Tiroir ouvert.'), icon: const Icon(Icons.inbox), label: const Text('Ouvrir le tiroir')),
              OutlinedButton.icon(onPressed: () async => toast(await printLines(zLines()) ?? 'Rapport imprimé.'), icon: const Icon(Icons.print), label: const Text('Rapport de la journée')),
              FilledButton.icon(
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: ctx,
                    builder: (d) => AlertDialog(
                      title: const Text('Clôturer la caisse ?'),
                      content: const Text('Le rapport sera imprimé.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Clôturer')),
                      ],
                    ),
                  );
                  if (ok == true) { final e = await printLines(zLines()); if (e != null) toast(e); app.closeCash(); }
                },
                icon: const Icon(Icons.lock),
                label: const Text('Clôturer la caisse'),
              ),
            ]),
          ]);
        },
      );
}

// ------------------------------------------------------------ dépenses
class ExpensesPage extends StatelessWidget {
  const ExpensesPage({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final l = app.expenses.where((e) => sameDay(e.date, DateTime.now())).toList();
          return Scaffold(
            floatingActionButton: FloatingActionButton.extended(
              icon: const Icon(Icons.add),
              label: const Text('Nouvelle dépense'),
              onPressed: () async {
                final lab = await ask(ctx, 'Nouvelle dépense', label: 'Libellé');
                if (lab == null || lab.isEmpty || !ctx.mounted) return;
                final v = num_(await ask(ctx, lab, label: 'Montant', kb: _numKb));
                if (v != null) app.addExpense(lab, v);
              },
            ),
            body: ListView(padding: const EdgeInsets.all(16), children: [
              Wrap(spacing: 12, children: [stat("Total des dépenses (aujourd'hui)", money(l.fold<double>(0, (s, e) => s + e.amount))), stat('Nombre', '${l.length}')]),
              if (l.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Aucune dépense sur cette période.'))),
              for (final e in l) ListTile(title: Text(e.label), subtitle: Text(fdt(e.date)), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(money(e.amount)), IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => app.delExpense(e.id))])),
            ]),
          );
        },
      );
}

// ------------------------------------------------------------ rapports
class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _ReportsState();
}

class _ReportsState extends State<ReportsPage> {
  int k = 0;
  List<DateTime> range() {
    final n = DateTime.now();
    final d = DateTime(n.year, n.month, n.day);
    final tom = d.add(const Duration(days: 1));
    if (k == 0) return [d, tom];
    if (k == 1) return [d.subtract(const Duration(days: 1)), d];
    if (k == 2) return [d.subtract(const Duration(days: 6)), tom];
    return [DateTime(n.year, n.month, 1), tom];
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final r = range();
          final paid = app.paidIn(r[0], r[1]);
          final ca = paid.fold<double>(0, (s, o) => s + o.total);
          final by = app.byMethod(paid);
          final top = <String, List<double>>{};
          for (final o in paid) { for (final l in o.lines) { final t = top.putIfAbsent(l.name, () => [0, 0]); t[0] += l.qty; t[1] += l.total; } }
          final tops = top.entries.toList()..sort((a, b) => b.value[1].compareTo(a.value[1]));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Wrap(spacing: 8, children: [for (var i = 0; i < 4; i++) ChoiceChip(label: Text(["Aujourd'hui", 'Hier', '7 jours', 'Ce mois'][i]), selected: k == i, onSelected: (_) => setState(() => k = i))]),
            const SizedBox(height: 12),
            Wrap(spacing: 12, runSpacing: 12, children: [
              stat("Chiffre d'affaires", money(ca)),
              stat('Tickets', '${paid.length}'),
              stat('Panier moyen', money(paid.isEmpty ? 0 : ca / paid.length)),
              stat('Dépenses', money(app.expensesIn(r[0], r[1]))),
            ]),
            const SizedBox(height: 16),
            const Text('Moyens de paiement', style: TextStyle(fontWeight: FontWeight.bold)),
            for (final e in by.entries) ListTile(dense: true, title: Text(e.key), trailing: Text(money(e.value))),
            const SizedBox(height: 8),
            const Text('Produits les plus vendus', style: TextStyle(fontWeight: FontWeight.bold)),
            for (final e in tops.take(10)) ListTile(dense: true, title: Text(e.key), subtitle: Text('${e.value[0].toInt()} vendus'), trailing: Text(money(e.value[1]))),
          ]);
        },
      );
}

// ------------------------------------------------------------ réglages
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  void _open(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));
  @override
  Widget build(BuildContext context) => ListView(children: [
        ListTile(leading: const Icon(Icons.store), title: const Text('Établissement'), subtitle: const Text('Nom, adresse, téléphone, message du ticket'), onTap: () => _open(context, const SetupScreen(editing: true))),
        ListTile(leading: const Icon(Icons.restaurant_menu), title: const Text('Menu'), subtitle: const Text('Catégories et articles'), onTap: () => _open(context, const MenuScreen())),
        ListTile(leading: const Icon(Icons.print), title: const Text('Imprimantes'), subtitle: const Text('Citaq H10 intégrée, Bluetooth, Android'), onTap: () => _open(context, const PrintersScreen())),
        ListTile(
          leading: const Icon(Icons.table_restaurant),
          title: const Text('Salle & tables'),
          subtitle: Text('${app.nSalle} tables en salle, ${app.nTerrasse} en terrasse'),
          onTap: () async {
            final a = int.tryParse(await ask(context, 'Tables en salle', init: '${app.nSalle}', kb: TextInputType.number) ?? '');
            if (a != null) app.nSalle = a;
            if (!context.mounted) return;
            final b = int.tryParse(await ask(context, 'Tables en terrasse', init: '${app.nTerrasse}', kb: TextInputType.number) ?? '');
            if (b != null) app.nTerrasse = b;
            app.save();
          },
        ),
      ]);
}

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Menu')),
        floatingActionButton: FloatingActionButton.extended(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ItemEditor())), icon: const Icon(Icons.add), label: const Text('Article')),
        body: ListenableBuilder(
          listenable: app,
          builder: (ctx, _) => ListView(padding: const EdgeInsets.only(bottom: 90), children: [
            ListTile(
              title: const Text('Catégories', style: TextStyle(fontWeight: FontWeight.bold)),
              trailing: IconButton(icon: const Icon(Icons.add), onPressed: () async => app.addCategory(await ask(ctx, 'Nouvelle catégorie', label: 'Nom') ?? '')),
            ),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Wrap(spacing: 8, children: [for (final c in app.categories) InputChip(label: Text(c), onDeleted: () => app.delCategory(c))])),
            const Divider(),
            for (final it in app.items)
              ListTile(
                leading: SizedBox(width: 56, height: 56, child: ClipRRect(borderRadius: BorderRadius.circular(8), child: itemImage(it.image))),
                title: Text(it.name),
                subtitle: Text('${money(it.price)} · ${it.category}'),
                onTap: () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => ItemEditor(item: it))),
                trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => app.deleteItem(it.id)),
              ),
          ]),
        ),
      );
}

class ItemEditor extends StatefulWidget {
  final Item? item;
  const ItemEditor({super.key, this.item});
  @override
  State<ItemEditor> createState() => _ItemEditorState();
}

class _ItemEditorState extends State<ItemEditor> {
  late final n = TextEditingController(text: widget.item?.name);
  late final pr = TextEditingController(text: widget.item == null ? '' : widget.item!.price.toStringAsFixed(2));
  late final url = TextEditingController(text: (widget.item?.image ?? '').startsWith('http') ? widget.item!.image : '');
  late String? image = widget.item?.image;
  late String? cat = widget.item?.category.isNotEmpty == true ? widget.item!.category : (app.categories.isEmpty ? null : app.categories.first);

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 900, imageQuality: 80);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = p.join(dir.path, '${DateTime.now().millisecondsSinceEpoch}${p.extension(x.path)}');
    await File(x.path).copy(dest);
    setState(() { image = dest; url.clear(); });
  }

  Future<void> _save() async {
    final price = num_(pr.text.trim());
    if (n.text.trim().isEmpty || price == null || price < 0) return toast('Nom et prix valides obligatoires.');
    await app.upsertItem(Item(id: widget.item?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), name: n.text.trim(), price: price, image: image, category: cat ?? ''));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.item == null ? 'Nouvel article' : "Modifier l'article")),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: ListView(padding: const EdgeInsets.all(16), children: [
              field(n, 'Nom du plat'),
              field(pr, 'Prix', kb: _numKb),
              DropdownButtonFormField<String>(
                value: cat,
                decoration: const InputDecoration(labelText: 'Catégorie', border: OutlineInputBorder()),
                items: [for (final c in app.categories) DropdownMenuItem(value: c, child: Text(c))],
                onChanged: (v) => setState(() => cat = v),
              ),
              const SizedBox(height: 12),
              SizedBox(height: 160, child: ClipRRect(borderRadius: BorderRadius.circular(12), child: itemImage(image))),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: _pick, icon: const Icon(Icons.photo_library), label: const Text('Importer depuis la galerie')),
              const SizedBox(height: 12),
              field(url, "…ou URL d'une image (https://…)", kb: TextInputType.url, onChanged: (v) => setState(() => image = v.trim().isEmpty ? null : v.trim())),
              FilledButton(onPressed: _save, child: const Text('Enregistrer')),
            ]),
          ),
        ),
      );
}

class PrintersScreen extends StatefulWidget {
  const PrintersScreen({super.key});
  @override
  State<PrintersScreen> createState() => _PrintersState();
}

class _PrintersState extends State<PrintersScreen> {
  late final path = TextEditingController(text: app.serialPath);

  Future<void> _pickBt() async {
    await [Permission.bluetoothConnect, Permission.bluetoothScan].request();
    final list = await PrintBluetoothThermal.pairedBluetooths;
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (d) => SimpleDialog(
        title: const Text('Imprimantes Bluetooth appairées'),
        children: list.isEmpty
            ? [const Padding(padding: EdgeInsets.all(16), child: Text("Aucune. Appairez l'imprimante dans les réglages Bluetooth d'Android."))]
            : [for (final b in list) SimpleDialogOption(onPressed: () { app.btMac = b.macAdress; app.btName = b.name; app.save(); Navigator.pop(d); }, child: Text('${b.name}\n${b.macAdress}'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Imprimantes')),
        body: ListenableBuilder(
          listenable: app,
          builder: (ctx, _) => ListView(padding: const EdgeInsets.all(16), children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'citaq', label: Text('Citaq H10 (intégrée)')),
                ButtonSegment(value: 'bt', label: Text('Bluetooth')),
                ButtonSegment(value: 'system', label: Text('Android (PDF)')),
              ],
              selected: {app.mode},
              onSelectionChanged: (s) { app.mode = s.first; app.save(); },
            ),
            const SizedBox(height: 16),
            if (app.mode == 'citaq') ...[
              field(path, 'Chemin du port série (essayez /dev/ttyS1, ttyS3, ttyUSB0)', onChanged: (v) { app.serialPath = v.trim(); app.save(); }),
              const Text('Vitesse : 115200 bauds (déjà réglée par le terminal).'),
            ],
            if (app.mode == 'bt') ListTile(leading: const Icon(Icons.bluetooth), title: const Text('Choisir une imprimante'), subtitle: Text(app.btName.isEmpty ? 'Aucune' : app.btName), onTap: _pickBt),
            SwitchListTile(title: const Text('Papier 58 mm (sinon 80 mm)'), value: app.paper58, onChanged: (v) { app.paper58 = v; app.save(); }),
            const SizedBox(height: 8),
            Wrap(spacing: 12, children: [
              FilledButton.icon(
                icon: const Icon(Icons.print),
                label: const Text('Imprimer un test'),
                onPressed: () async {
                  final o = Order(id: 't', no: 0, service: 'Test', date: DateTime.now(), lines: [Line('t', 'Article test', 1.5, 2)]);
                  toast(await printLines(receiptLines(o)) ?? 'Test envoyé.');
                },
              ),
              OutlinedButton.icon(icon: const Icon(Icons.inbox), label: const Text('Ouvrir le tiroir'), onPressed: () async => toast(await openDrawer() ?? 'Commande envoyée.')),
            ]),
          ]),
        ),
      );
}
