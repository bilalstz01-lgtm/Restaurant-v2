import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

class AppState extends ChangeNotifier {
  static const services = ['Salle', 'Terrasse', 'À emporter', 'Livraison', 'GLOVO'];
  static const methods = ['Espèces', 'Carte bancaire', 'Ticket restaurant', 'Glovo', 'Autre'];

  late SharedPreferences _p;
  Restaurant? resto;
  List<String> categories = ['Plats', 'Boissons', 'Desserts'];
  List<Item> items = [];
  List<Order> orders = [];
  List<Expense> expenses = [];
  int orderNo = 0, nSalle = 8, nTerrasse = 4;
  String mode = 'citaq', serialPath = '/dev/ttyS1', btMac = '', btName = '';
  bool paper58 = true;
  double cashFloat = 0;
  DateTime? cashOpened;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final s = _p.getString('db');
    if (s == null) return;
    final d = jsonDecode(s) as Map<String, dynamic>;
    if (d['resto'] != null) resto = Restaurant.fromJson(d['resto']);
    categories = List<String>.from(d['cats'] ?? categories);
    items = (d['items'] as List? ?? []).map((e) => Item.fromJson(e)).toList();
    orders = (d['orders'] as List? ?? []).map((e) => Order.fromJson(e)).toList();
    expenses = (d['exp'] as List? ?? []).map((e) => Expense.fromJson(e)).toList();
    orderNo = d['no'] ?? 0;
    nSalle = d['nS'] ?? 8;
    nTerrasse = d['nT'] ?? 4;
    mode = d['mode'] ?? 'citaq';
    serialPath = d['serial'] ?? '/dev/ttyS1';
    btMac = d['btMac'] ?? '';
    btName = d['btName'] ?? '';
    paper58 = d['p58'] ?? true;
    cashFloat = (d['float'] ?? 0).toDouble();
    cashOpened = d['opened'] == null ? null : DateTime.parse(d['opened']);
  }

  Future<void> save() async {
    await _p.setString('db', jsonEncode({
      'resto': resto?.toJson(), 'cats': categories,
      'items': items.map((e) => e.toJson()).toList(),
      'orders': orders.map((e) => e.toJson()).toList(),
      'exp': expenses.map((e) => e.toJson()).toList(),
      'no': orderNo, 'nS': nSalle, 'nT': nTerrasse, 'mode': mode, 'serial': serialPath,
      'btMac': btMac, 'btName': btName, 'p58': paper58, 'float': cashFloat,
      'opened': cashOpened?.toIso8601String(),
    }));
    notifyListeners();
  }

  Future<void> saveResto(Restaurant r) async { resto = r; await save(); }
  Future<void> upsertItem(Item i) async {
    final k = items.indexWhere((e) => e.id == i.id);
    if (k >= 0) { items[k] = i; } else { items.add(i); }
    await save();
  }
  Future<void> deleteItem(String id) async { items.removeWhere((e) => e.id == id); await save(); }
  Future<void> addCategory(String c) async { if (c.isNotEmpty && !categories.contains(c)) { categories.add(c); await save(); } }
  Future<void> delCategory(String c) async { categories.remove(c); await save(); }

  // ----- commandes
  Order? openOrder(String service, String? table) => orders.where((o) => o.status == 'open' && o.service == service && o.table == table).firstOrNull;
  Order newOrder(String service, String? table) => Order(id: DateTime.now().microsecondsSinceEpoch.toString(), no: 0, service: service, table: table, date: DateTime.now());
  void _ensure(Order o) { if (!orders.contains(o)) { o.no = ++orderNo; orders.add(o); } }
  void addItem(Order o, Item i) {
    _ensure(o);
    final l = o.lines.where((x) => x.id == i.id).firstOrNull;
    if (l == null) { o.lines.add(Line(i.id, i.name, i.price, 1)); } else { l.qty++; }
    save();
  }
  void inc(Order o, Line l) { l.qty++; save(); }
  void dec(Order o, Line l) {
    l.qty--;
    if (l.qty <= 0) o.lines.remove(l);
    if (o.lines.isEmpty) orders.remove(o);
    save();
  }
  void markSent(Order o) { for (final l in o.lines) { l.sent = l.qty; } save(); }
  void pay(Order o, String m) { o.status = 'paid'; o.pay = m; o.paidAt = DateTime.now(); save(); }

  // ----- caisse / dépenses
  void openCash(double f) { cashFloat = f; cashOpened = DateTime.now(); save(); }
  void closeCash() { cashOpened = null; save(); }
  void addExpense(String label, double a) { expenses.add(Expense(DateTime.now().microsecondsSinceEpoch.toString(), label, a, DateTime.now())); save(); }
  void delExpense(String id) { expenses.removeWhere((e) => e.id == id); save(); }

  List<Order> paidIn(DateTime a, DateTime b) => orders.where((o) => o.status == 'paid' && o.paidAt != null && !o.paidAt!.isBefore(a) && o.paidAt!.isBefore(b)).toList();
  List<Order> paidSince(DateTime a) => paidIn(a, DateTime.now().add(const Duration(days: 1)));
  double expensesIn(DateTime a, DateTime b) => expenses.where((e) => !e.date.isBefore(a) && e.date.isBefore(b)).fold<double>(0, (s, e) => s + e.amount);
  double expensesSince(DateTime a) => expensesIn(a, DateTime.now().add(const Duration(days: 1)));
  Map<String, double> byMethod(List<Order> l) {
    final m = <String, double>{for (final x in methods) x: 0.0};
    for (final o in l) { final k = o.pay ?? 'Autre'; m[k] = (m[k] ?? 0) + o.total; }
    return m;
  }
  double get expectedCash {
    final a = cashOpened;
    if (a == null) return 0;
    return cashFloat + (byMethod(paidSince(a))['Espèces'] ?? 0) - expensesSince(a);
  }
}

final app = AppState();
String money(double v) => '${v.toStringAsFixed(2)} ${app.resto?.currency ?? ''}'.trim();
