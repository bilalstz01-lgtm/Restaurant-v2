class Restaurant {
  final String name, address, phone, currency, footer;
  const Restaurant(this.name, this.address, this.phone, this.currency, this.footer);
  Map<String, dynamic> toJson() => {'name': name, 'address': address, 'phone': phone, 'currency': currency, 'footer': footer};
  factory Restaurant.fromJson(Map<String, dynamic> j) => Restaurant(j['name'], j['address'] ?? '', j['phone'] ?? '', j['currency'] ?? '€', j['footer'] ?? 'Merci de votre visite !');
}

class Item {
  final String id, name, category;
  final double price;
  final String? image;
  const Item({required this.id, required this.name, required this.price, this.image, this.category = ''});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'price': price, 'image': image, 'category': category};
  factory Item.fromJson(Map<String, dynamic> j) => Item(id: j['id'], name: j['name'], price: (j['price'] as num).toDouble(), image: j['image'], category: j['category'] ?? '');
}

class Line {
  final String id, name;
  final double price;
  int qty, sent;
  Line(this.id, this.name, this.price, this.qty, [this.sent = 0]);
  double get total => price * qty;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'price': price, 'qty': qty, 'sent': sent};
  factory Line.fromJson(Map<String, dynamic> j) => Line(j['id'], j['name'], (j['price'] as num).toDouble(), j['qty'], j['sent'] ?? 0);
}

class Order {
  final String id, service;
  final String? table;
  final DateTime date;
  final List<Line> lines;
  int no;
  String status; // open | paid
  String? pay;
  DateTime? paidAt;
  Order({required this.id, required this.no, required this.service, this.table, required this.date, List<Line>? lines, this.status = 'open', this.pay, this.paidAt})
      : lines = lines ?? <Line>[];
  double get total => lines.fold<double>(0, (s, l) => s + l.total);
  String get label => table == null ? service : '$service · $table';
  Map<String, dynamic> toJson() => {'id': id, 'no': no, 'service': service, 'table': table, 'date': date.toIso8601String(), 'lines': lines.map((e) => e.toJson()).toList(), 'status': status, 'pay': pay, 'paidAt': paidAt?.toIso8601String()};
  factory Order.fromJson(Map<String, dynamic> j) => Order(id: j['id'], no: j['no'], service: j['service'], table: j['table'], date: DateTime.parse(j['date']), lines: (j['lines'] as List).map((e) => Line.fromJson(e)).toList(), status: j['status'], pay: j['pay'], paidAt: j['paidAt'] == null ? null : DateTime.parse(j['paidAt']));
}

class Expense {
  final String id, label;
  final double amount;
  final DateTime date;
  const Expense(this.id, this.label, this.amount, this.date);
  Map<String, dynamic> toJson() => {'id': id, 'label': label, 'amount': amount, 'date': date.toIso8601String()};
  factory Expense.fromJson(Map<String, dynamic> j) => Expense(j['id'], j['label'], (j['amount'] as num).toDouble(), DateTime.parse(j['date']));
}
