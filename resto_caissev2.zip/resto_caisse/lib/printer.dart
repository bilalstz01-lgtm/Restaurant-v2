import 'dart:io';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:printing/printing.dart';
import 'models.dart';
import 'state.dart';

const _m = {
  'à': 'a', 'â': 'a', 'ä': 'a', 'á': 'a', 'ã': 'a', 'ç': 'c', 'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e',
  'í': 'i', 'î': 'i', 'ï': 'i', 'ñ': 'n', 'ó': 'o', 'ô': 'o', 'ö': 'o', 'ú': 'u', 'ù': 'u', 'û': 'u',
  'ü': 'u', 'œ': 'oe', 'À': 'A', 'Â': 'A', 'Ç': 'C', 'É': 'E', 'È': 'E', 'Ê': 'E', 'Î': 'I', 'Ô': 'O',
  'Ù': 'U', 'Û': 'U', '€': 'EUR', '°': 'o', '·': '-', '’': "'",
};
String noAccent(String s) => s.split('').map((c) => _m[c] ?? c).join();

int get _w => app.paper58 ? 32 : 48;
String _t(String s) => app.mode == 'system' ? s : noAccent(s);
String _c(String s) => s.length >= _w ? s : ' ' * ((_w - s.length) ~/ 2) + s;
String _sep() => '-' * _w;
String _mny(double v) => '${v.toStringAsFixed(2)} ${_t(app.resto?.currency ?? '')}'.trim();
String _lr(String a, String b) {
  final sp = _w - a.length - b.length;
  if (sp < 1) {
    final cut = (_w - b.length - 1).clamp(0, a.length);
    return '${a.substring(0, cut)} $b';
  }
  return a + ' ' * sp + b;
}

List<String> _wrap(String s) {
  final out = <String>[];
  var cur = '';
  for (final w in s.split(' ')) {
    if (('$cur $w').trim().length > _w) {
      if (cur.isNotEmpty) out.add(cur);
      cur = w;
    } else {
      cur = ('$cur $w').trim();
    }
  }
  if (cur.isNotEmpty) out.add(cur);
  return out;
}

List<String> _header() {
  final r = app.resto!;
  return [
    for (final l in _wrap(_t(r.name).toUpperCase())) _c(l),
    for (final l in _wrap(_t(r.address))) _c(l),
    if (r.phone.isNotEmpty) _c('Tel: ${_t(r.phone)}'),
    _sep(),
  ];
}

List<String> receiptLines(Order o, {String? title}) {
  final out = <String>[..._header()];
  if (title != null) { out.add(_c(title)); out.add(_sep()); }
  out.add('Ticket #${o.no.toString().padLeft(4, '0')}  ${_t(o.label)}');
  out.add(DateFormat('dd/MM/yyyy HH:mm').format(o.paidAt ?? DateTime.now()));
  out.add(_sep());
  for (final l in o.lines) {
    out.addAll(_wrap(_t(l.name)));
    out.add(_lr('  ${l.qty} x ${_mny(l.price)}', _mny(l.total)));
  }
  out.add(_sep());
  out.add(_lr('TOTAL', _mny(o.total)));
  out.add(_sep());
  if (o.pay != null) out.add('Paiement: ${_t(o.pay!)}');
  out.add(_c(_t(app.resto!.footer)));
  return out;
}

List<String> kitchenLines(Order o) {
  final out = <String>[
    _c('*** CUISINE ***'),
    _c(_t(o.label)),
    'Cmd #${o.no}  ${DateFormat('HH:mm').format(DateTime.now())}',
    _sep(),
  ];
  for (final l in o.lines.where((l) => l.qty > l.sent)) {
    out.addAll(_wrap('${l.qty - l.sent} x ${_t(l.name)}'));
  }
  out.add(_sep());
  return out;
}

List<String> zLines() {
  final a = app.cashOpened ?? DateTime.now();
  final paid = app.paidSince(a);
  final sales = paid.fold<double>(0, (s, o) => s + o.total);
  final out = <String>[
    ..._header(),
    _c('RAPPORT DE CAISSE'),
    DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()),
    _sep(),
    _lr('Fond de caisse', _mny(app.cashFloat)),
    _lr('Tickets', '${paid.length}'),
    _lr('Ventes', _mny(sales)),
  ];
  for (final e in app.byMethod(paid).entries) { out.add(_lr(_t(e.key), _mny(e.value))); }
  out.add(_lr('Depenses', _mny(app.expensesSince(a))));
  out.add(_sep());
  out.add(_lr('Especes attendues', _mny(app.expectedCash)));
  return out;
}

Future<String?> printLines(List<String> lines, {bool kick = false}) async {
  try {
    if (app.mode == 'system') { await _system(lines); return null; }
    final g = Generator(app.paper58 ? PaperSize.mm58 : PaperSize.mm80, await CapabilityProfile.load());
    List<int> b = [];
    b += g.reset();
    for (final l in lines) { b += g.text(l); }
    b += g.feed(2);
    b += g.cut();
    if (kick) b += g.drawer();
    return await _send(b);
  } catch (e) {
    return "Erreur d'impression : $e";
  }
}

Future<String?> openDrawer() async {
  final g = Generator(app.paper58 ? PaperSize.mm58 : PaperSize.mm80, await CapabilityProfile.load());
  return _send(g.drawer());
}

Future<String?> _send(List<int> b) => app.mode == 'bt' ? _bt(b) : _serial(b);

/// Imprimante intégrée (Citaq H10) : écriture directe sur le port série.
Future<String?> _serial(List<int> b) async {
  RandomAccessFile? f;
  try {
    f = await File(app.serialPath).open(mode: FileMode.writeOnlyAppend);
    await f.writeFrom(b);
    await f.flush();
    return null;
  } catch (e) {
    return 'Port ${app.serialPath} inaccessible : $e';
  } finally {
    await f?.close();
  }
}

Future<String?> _bt(List<int> b) async {
  if (app.btMac.isEmpty) return 'Aucune imprimante Bluetooth choisie.';
  await [Permission.bluetoothConnect, Permission.bluetoothScan].request();
  if (!await PrintBluetoothThermal.bluetoothEnabled) return 'Bluetooth désactivé.';
  if (!await PrintBluetoothThermal.connectionStatus) {
    if (!await PrintBluetoothThermal.connect(macPrinterAddress: app.btMac)) return 'Connexion Bluetooth impossible.';
  }
  return await PrintBluetoothThermal.writeBytes(b) ? null : "Échec de l'impression.";
}

Future<void> _system(List<String> lines) async {
  final doc = pw.Document();
  final pf = app.paper58 ? PdfPageFormat.roll57 : PdfPageFormat.roll80;
  doc.addPage(pw.Page(
    pageFormat: pf,
    margin: pw.EdgeInsets.all(2 * PdfPageFormat.mm),
    build: (_) => pw.Text(lines.join('\n'), style: pw.TextStyle(font: pw.Font.courier(), fontSize: app.paper58 ? 7.5 : 7)),
  ));
  await Printing.layoutPdf(onLayout: (_) => doc.save(), name: 'Ticket');
}
